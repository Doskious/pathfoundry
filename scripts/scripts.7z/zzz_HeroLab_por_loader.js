var tasmin;

$.ajax({
    url:'/custom//Crimson Throne/Characters/Damsels of Distress.por',
    dataType: 'binary',
    processData: false,
    type: 'GET'
}).then(function(data){
    glup = new zip.fs.FS();
    glup.importBlob(data, function() {
        glup.entries[83].getText(function(charXML) {
            tasmin = parsePathfinderCharacter($($.parseXML(charXML.replace(/&/g, "&amp;"))).find('public > character'), false);
        });
    });
});